<?php

/**
 * Template Name: Hoteis Padrao
 *
 * Página dedicada à apresentação da rede de hotéis San Diego.
 *
 * @package Tema_Dev_Gamb
 */

get_header();
?>

<?php get_template_part('template-parts/sections/section', 'banner-hoteis'); ?>
<?php get_template_part('template-parts/sections/section', 'search'); ?>

<?php get_template_part('template-parts/sections/section', 'grid-hoteis'); ?>
<?php get_template_part('template-parts/sections/section', 'experiencia'); ?>
<?php get_template_part('template-parts/sections/section', 'instagram'); ?>



<?php
  if (have_rows('hotel_sections')) :
    while (have_rows('hotel_sections')) :
      the_row();


      if (get_row_layout() === 'founders') {
        get_template_part('template-parts/sections/section', 'fundador');
      }

      if (get_row_layout() === 'timeline') {
        get_template_part('template-parts/sections/section', 'timeline');
      }

      if (get_row_layout() === 'leadership') {
        get_template_part('template-parts/sections/section', 'leadership');
      }
    endwhile;
  endif;
  ?>
</main>
<?php
get_footer();
