<?php

/**
 * Template Name: Hoteis rev.021225
 *
 * Página dedicada à apresentação da rede de hotéis San Diego.
 *
 * @package Tema_Dev_Gamb
 */

get_header();
?>

<?php get_template_part('template-parts/sections/section', 'banner-hoteis'); ?>
<?php get_template_part('template-parts/sections/section', 'search'); ?>

<!-- hoteis-grid -->
<?php get_template_part('template-parts/sections/section', 'hoteis-grid'); ?>
<!-- grid-hoteis -->
<?php get_template_part('template-parts/sections/section', 'grid-hoteis'); ?>
<!-- hoteis-experiencia -->
<?php get_template_part('template-parts/sections/section', 'hoteis-experiencia'); ?>
<!-- instagram -->
<?php get_template_part('template-parts/sections/section', 'instagram'); ?>
<!-- hoteis-instagram -->
<?php get_template_part('template-parts/sections/section', 'hoteis-instagram'); ?>


</main>
<?php
get_footer();
