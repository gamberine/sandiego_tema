<!-- < ?php
/**
 * Template Name: Home San Diego
 *
 * Página com destaques das ofertas cadastradas no CPT ofertas.
 *
 * @package Tema_Dev_Gamb
 */

get_header();
?> -->
<!-- <main id="primary" class="site-main sandiego">
 
  < ?php if (have_rows('home_sections')): while (have_rows('home_sections')): the_row();
      if (get_row_layout() == 'banner') get_template_part('template-parts/sections/section', 'banner');
      if (get_row_layout() == 'search') get_template_part('template-parts/sections/section', 'search');
      if (get_row_layout() == 'services') get_template_part('template-parts/sections/section', 'services');
      if (get_row_layout() == 'numbers') get_template_part('template-parts/sections/section', 'numbers');
      if (get_row_layout() == 'differentials') get_template_part('template-parts/sections/section', 'differentials');
      if (get_row_layout() == 'contact') get_template_part('template-parts/sections/section', 'contact');
    endwhile;
  endif; ?>
</main>
< ?php get_footer(); ?> -->