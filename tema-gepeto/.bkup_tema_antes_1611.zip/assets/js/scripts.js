/* 
 * San Diego Hotéis 2025
 * Arquivo unificado de scripts do tema.
 *
 * Conteúdo:
 * 1. scripts.js original – efeitos gerais, menu, sliders genéricos, WOW, menu fixo.
 * 2. sandiego.js original – carrosséis das páginas (home, single, depoimentos) e botões de cópia [sd_copy].
 *
 * Observação:
 * Nenhum bloco duplicado exato foi encontrado entre os dois arquivos.
 * Todo o conteúdo foi mantido na íntegra, apenas reorganizado neste arquivo único,
 * com pequenos ajustes de comentários e pontos de responsividade.
 */


/* === INICIO scripts.js (original, ajustado) === */

/*Adicionar Loading no carregamento de telas*/
jQuery(document).ready(function() {
    jQuery('#loading').show();
    jQuery(window).load(function() {
        // Quando a página estiver totalmente carregada, remove o id
        jQuery('#loading').fadeOut('slow');
    });
});
jQuery(document).ready(function() {
    jQuery('#primary-mobile-menu').click(function() {
        if (jQuery('.primary-menu-container').hasClass('aparecer')) {
            jQuery('.primary-menu-container').removeClass('aparecer');



        } else {
            jQuery('.primary-menu-container').removeClass('aparecer');
            jQuery('.primary-menu-container').addClass('aparecer');
        }
    })
});
/*Ativação de Ícones de Seguros*/
jQuery(document).ready(function() {
    jQuery('.publicoAlvo a[href*=pessoa-fisica]').each(function() {
        jQuery('.simboloPf').addClass('simboloAtivo');
    })
    jQuery('.publicoAlvo a[href*=pessoa-juridica]').each(function() {
        jQuery('.simboloPj').addClass('simboloAtivo');
    })
});

/*Banners*/
jQuery(document).on('ready', function() {

    jQuery('.bannerPrincipal').slick({
        dots: true,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 6000,
        slidesToShow: 1,
        speed: 500,
        slidesToScroll: 1

    });
    jQuery('.bannerParceiros').slick({
        dots: true,
        arrows: true,
        autoplay: true,
        autoplaySpeed: 6000,
        slidesToShow: 3,
        speed: 500,
        slidesToScroll: 3,
        responsive: [{
                breakpoint: 1260,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 550,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            // Você pode desativar o slick (unslick) em um breakpoint específico adicionando:
            // settings: "unslick"
            // em vez de um objeto completo de configurações
        ]

    });
    jQuery('.bannerDepoimentos').slick({
        dots: true,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 6000,
        slidesToShow: 2,
        speed: 500,
        slidesToScroll: 2,
        responsive: [{
                breakpoint: 980,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }


            // Você pode desativar o slick (unslick) em um breakpoint específico adicionando:
            // settings: "unslick"
            // em vez de um objeto completo de configurações
        ]

    });
});

// Wow JS intalação
jQuery(document).ready(function() {
    var wow = new WOW({
        boxClass: 'wow', // classe CSS dos elementos animados (padrão é "wow")
        animateClass: 'animated', // classe CSS de animação (padrão é "animated")
        offset: 0, // distância até o elemento para disparar a animação (padrão é 0)
        mobile: true, // ativa animações em dispositivos móveis (padrão é true)
        live: true, // observa conteúdo carregado de forma assíncrona (padrão é true)
        callback: function(box) { // função chamada sempre que uma animação começa; "box" é o elemento animado
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
        },
        scrollContainer: null // seletor opcional de container de scroll (padrão é a janela)
    });
    wow.init();
});

/*Travar Menu*/
jQuery(window).scroll(function() {
    if (jQuery(window).scrollTop() >= 300) {
        jQuery("header.site-header").addClass('menuSuspenso');
    } else {
        jQuery("header.site-header").removeClass('menuSuspenso');
    };
});

/* === FIM scripts.js (original, ajustado) === */

/* === INICIO sandiego.js (original, ajustado) === */

(function(jQuery){
  jQuery(document).ready(function(){
    // Carrossel de hotéis na home
    if (jQuery('.sd-carousel-hotels').length) {
      jQuery('.sd-carousel-hotels').slick({
        dots:true, arrows:false, autoplay:true, autoplaySpeed:4500,
        slidesToShow:4, slidesToScroll:4,
        responsive:[
          {breakpoint:1260, settings:{slidesToShow:3, slidesToScroll:3}},
          {breakpoint:992, settings:{slidesToShow:2, slidesToScroll:2}},
          {breakpoint:576, settings:{slidesToShow:1, slidesToScroll:1}}
        ]
      });
    }

    // Carrossel de quartos na página single
    if (jQuery('.sd-carousel-rooms').length) {
      jQuery('.sd-carousel-rooms').slick({
        dots:true, arrows:true, autoplay:true, autoplaySpeed:4500,
        slidesToShow:3, slidesToScroll:1,
        responsive:[
          {breakpoint:992, settings:{slidesToShow:2}},
          {breakpoint:576, settings:{slidesToShow:1}}
        ]
      });
    }

    // Carrossel de depoimentos
    if (jQuery('.sd-carousel-depo').length) {
      jQuery('.sd-carousel-depo').slick({
        dots:true, arrows:false, autoplay:true, autoplaySpeed:6000,
        slidesToShow:2, slidesToScroll:2,
        responsive:[{breakpoint:992, settings:{slidesToShow:1, slidesToScroll:1}}]
      });
    }
  });

  // Função para copiar texto para a área de transferência
  function doCopy(text){
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
    }
  }

  // Botão shortcode [sd_copy]
  jQuery(document).on('click','.sd-copy',function(e){
    e.preventDefault();
    var t=jQuery(this).data('copy')||jQuery(this).text();
    doCopy(t);
  });

  // Copiar com atributo data-copy-inline
  jQuery(document).on('click','[data-copy-inline]',function(e){
    e.preventDefault();
    var t=jQuery(this).attr('data-copy-inline')||jQuery(this).text();
    doCopy(t);
  });
})(jQuery);


/* === FIM sandiego.js (original, ajustado) === */

/* Nenhum trecho foi desativado por duplicidade; apenas comentários foram traduzidos e pontos de responsividade ajustados. */
