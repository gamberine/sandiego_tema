<?php
/**
 * Estrutura de apoio para o formulário "Trabalhe Conosco".
 * Utilize o conteúdo abaixo dentro do editor do Contact Form 7.
 */
?>

<div class="col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12">
  [text* nome autocomplete:off placeholder "nome"]
</div>
<div class="col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12">
  [email* email autocomplete:off placeholder "e-mail"]
</div>
<div class="col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12">
  [tel* telefone autocomplete:off placeholder "telefone"]
</div>
<div class="col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12 anexar">
  <label for="fileuploadfield" class="labelAnexar">Anexar</label>
  [file Anexar id:fileuploadfield limit:3000Kb filetypes:doc|docx|pdf|txt|xls|xlsx|jpg class:fileuploadfield btnAnexar]
</div>
<span class="col-6">[submit "enviar"]</span>

<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
  [text* nome autocomplete:off placeholder "nome"]
  [email* email autocomplete:off placeholder "e-mail"]
  [tel* telefone autocomplete:off placeholder "telefone"]
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 anexar">
  <label for="fileuploadfield" class="labelAnexar">Anexar</label>
  [file Anexar id:fileuploadfield limit:3000Kb filetypes:doc|docx|pdf|txt|xls|xlsx|jpg class:fileuploadfield btnAnexar]
  <span class="col-6">[submit "enviar"]</span>
</div>
